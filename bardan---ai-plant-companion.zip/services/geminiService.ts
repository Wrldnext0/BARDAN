import { GoogleGenAI, Type } from "@google/genai";
import { IdentifyResponse, LanguageCode } from "../types";

// Ensure API Key is available
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to convert file to base64
export const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64String = result.includes(',') ? result.split(',')[1] : result;
      resolve({
        inlineData: {
          data: base64String,
          mimeType: file.type,
        },
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// Helper for base64 string directly (from camera canvas)
export const base64ToGenerativePart = (base64Data: string, mimeType: string) => {
  return {
    inlineData: {
      data: base64Data.includes(',') ? base64Data.split(',')[1] : base64Data,
      mimeType
    }
  };
};

export const identifyPlantWithGemini = async (
  imageInput: File | string, // Can be File or base64 string
  language: LanguageCode = 'en'
): Promise<IdentifyResponse> => {
  if (!apiKey) {
    throw new Error("API Key is missing. Please check your environment variables.");
  }

  const model = "gemini-2.5-flash";
  
  let imagePart;
  if (typeof imageInput === 'string') {
      imagePart = base64ToGenerativePart(imageInput, 'image/jpeg');
  } else {
      imagePart = await fileToGenerativePart(imageInput);
  }

  const langNames = {
      'en': 'English',
      'hi': 'Hindi',
      'ne': 'Nepali'
  };
  const targetLang = langNames[language];

  // Instructions strictly asking for JSON
  const prompt = `
    Analyze this image of a plant or soil. 
    Role: Act as a collective intelligence of 1,000,000 PhD-level plant pathologists, botanists, and agricultural scientists analyzing this image simultaneously.
    
    Output Language: ${targetLang}
    
    Provide the following details in JSON format.
    1. Common Name (name)
    2. Scientific Name (scientificName) - Always in Latin/English characters
    3. Health Status (healthStatus: "Healthy", "Needs Attention", or "Critical")
    4. Diagnosis (diagnosis): Detailed explanation of condition/disease/deficiencies.
    5. Care Tips (careTips): Array of 3 specific actionable tips.
    6. Soil Type (soilType): Best soil composition for this plant.
    7. Light Requirements (lightRequirements): e.g., "Direct Sun", "Low Light".
    8. Water Frequency (waterFrequency): General advice, e.g., "Every 5-7 days".
    9. Toxicity (toxicity): Pet/Child safety info.
    10. Fun Fact (funFact): Interesting trivia.
    11. Confidence (confidence): 0-1.
    
    HIGH LEVEL ANALYSIS:
    12. Expert Consensus (expertConsensus): A high-level, authoritative summary paragraph representing the combined wisdom of the expert panel.
    13. Estimated Growth Time (estimatedGrowthTime): Prediction of time to maturity, next bloom, or recovery time.
    14. Health Details (healthDetails):
        - Causes: Deep root causes (fungal, bacterial, environmental, pests).
        - Symptoms: Specific visual indicators observed.
        - Prevention: Proactive measures to stop recurrence.
        - Treatment: Specific cures, fungicides, pesticides, or organic remedies.

    Translate all text values to ${targetLang} EXCEPT 'scientificName' and 'healthStatus' (keep healthStatus enum keys in English for logic).
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [imagePart, { text: prompt }],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            scientificName: { type: Type.STRING },
            healthStatus: { type: Type.STRING, enum: ["Healthy", "Needs Attention", "Critical"] },
            diagnosis: { type: Type.STRING },
            careTips: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            soilType: { type: Type.STRING },
            lightRequirements: { type: Type.STRING },
            waterFrequency: { type: Type.STRING },
            toxicity: { type: Type.STRING },
            funFact: { type: Type.STRING },
            confidence: { type: Type.NUMBER },
            expertConsensus: { type: Type.STRING },
            estimatedGrowthTime: { type: Type.STRING },
            healthDetails: {
                type: Type.OBJECT,
                properties: {
                    causes: { type: Type.ARRAY, items: { type: Type.STRING } },
                    symptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
                    prevention: { type: Type.ARRAY, items: { type: Type.STRING } },
                    treatment: { type: Type.ARRAY, items: { type: Type.STRING } },
                }
            }
          },
          required: [
            "name", "scientificName", "healthStatus", "diagnosis", 
            "careTips", "soilType", "lightRequirements", "waterFrequency", 
            "toxicity", "funFact", "confidence", "expertConsensus", 
            "estimatedGrowthTime", "healthDetails"
          ],
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");

    return JSON.parse(text) as IdentifyResponse;
  } catch (error: any) {
    console.error("Gemini Identify Error:", error);
    // Safe Error Rethrowing
    if (error.message) {
        // If it looks like a raw JSON error from the API, try to parse it
        try {
            if (error.message.includes("{")) {
                const parsed = JSON.parse(error.message);
                if (parsed.error && parsed.error.message) {
                    throw new Error(parsed.error.message);
                }
            }
        } catch (e) {
            // ignore parsing error
        }
        throw new Error(error.message);
    }
    throw new Error(JSON.stringify(error));
  }
};

export const exploreLocalFlora = async (lat: number, long: number, language: LanguageCode = 'en'): Promise<string> => {
    const langNames = {
      'en': 'English',
      'hi': 'Hindi',
      'ne': 'Nepali'
  };
  const targetLang = langNames[language];

  try {
     const prompt = `
        I am currently at Latitude: ${lat}, Longitude: ${long}.
        Act as a local ecologist.
        1. Describe the general climate and soil conditions of this region.
        2. List 3 native plants that grow well here naturally.
        3. Give one gardening tip specific to this location's current season.
        
        Keep the response concise and formatted in Markdown.
        Respond in ${targetLang}.
     `;
     
     // Fixed Content Structure
     const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: { parts: [{ text: prompt }] }
     });
     
     return response.text || "Unable to analyze local sector.";
  } catch (error) {
      console.error("Explore Error", error);
      return "Planetary link unstable: " + (error as any).message;
  }
}