import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import HomeView from './views/HomeView';
import IdentifyView from './views/IdentifyView';
import CareView from './views/CareView';
import ExploreView from './views/ExploreView';
import AuthView from './views/AuthView';
import PaymentView from './views/PaymentView';
import { Plant, ViewState, LanguageCode, ScanHistoryItem, CareTask } from './types';

type AppStage = 'AUTH' | 'PAYMENT' | 'APP';

const App: React.FC = () => {
  const [appStage, setAppStage] = useState<AppStage>('AUTH');
  const [currentView, setCurrentView] = useState<ViewState>('HOME');
  const [plants, setPlants] = useState<Plant[]>([]);
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [manualTasks, setManualTasks] = useState<CareTask[]>([]);
  const [selectedPlant, setSelectedPlant] = useState<Plant | null>(null);

  // Initial Auth Check
  useEffect(() => {
      const user = localStorage.getItem('bardan_user');
      const sub = localStorage.getItem('bardan_subscription');

      if (user) {
          if (sub === 'active') {
              setAppStage('APP');
          } else {
              setAppStage('PAYMENT');
          }
      } else {
          setAppStage('AUTH');
      }
  }, []);

  // Load App Data
  useEffect(() => {
    if (appStage !== 'APP') return;

    // Plants
    const storedPlants = localStorage.getItem('bardan_plants');
    if (storedPlants) {
        try {
            const parsed = JSON.parse(storedPlants);
            const fixed = parsed.map((p: any) => ({
                ...p,
                nextWatering: p.nextWatering ? new Date(p.nextWatering) : undefined,
                lastWatered: p.lastWatered ? new Date(p.lastWatered) : undefined,
                dateAdded: p.dateAdded ? new Date(p.dateAdded) : new Date()
            }));
            setPlants(fixed);
        } catch (e) { console.error("Failed to load plants", e); }
    }
    
    // History
    const storedHistory = localStorage.getItem('bardan_history');
    if (storedHistory) {
         try {
            const parsed = JSON.parse(storedHistory);
            const fixed = parsed.map((p: any) => ({
                ...p,
                timestamp: p.timestamp ? new Date(p.timestamp) : new Date()
            }));
            setHistory(fixed);
        } catch (e) { console.error(e) }
    }

    // Manual Tasks
    const storedTasks = localStorage.getItem('bardan_tasks');
    if (storedTasks) {
        try {
            const parsed = JSON.parse(storedTasks);
            const fixed = parsed.map((t: any) => ({
                ...t,
                dueDate: new Date(t.dueDate)
            }));
            setManualTasks(fixed);
        } catch (e) { console.error(e) }
    }
  }, [appStage]);

  // Save data to local storage on change
  useEffect(() => { localStorage.setItem('bardan_plants', JSON.stringify(plants)); }, [plants]);
  useEffect(() => { localStorage.setItem('bardan_history', JSON.stringify(history)); }, [history]);
  useEffect(() => { localStorage.setItem('bardan_tasks', JSON.stringify(manualTasks)); }, [manualTasks]);

  const handleAuthSuccess = () => {
      // Check subscription immediately after auth
      const sub = localStorage.getItem('bardan_subscription');
      if (sub === 'active') {
          setAppStage('APP');
      } else {
          setAppStage('PAYMENT');
      }
  };

  const handlePaymentSuccess = () => {
      setAppStage('APP');
  };

  const handleLogout = () => {
      localStorage.removeItem('bardan_user');
      // We assume logout clears session but maybe keeps plants? 
      // If we want full clear: localStorage.clear();
      setAppStage('AUTH');
  };

  const handleAddPlant = (newPlant: Plant) => {
    setPlants(prev => [newPlant, ...prev]);
    alert("Plant added to My Collection!");
    setCurrentView('HOME');
  };

  const handleAddToHistory = (item: ScanHistoryItem) => {
      setHistory(prev => [item, ...prev]);
  };

  const handleSelectPlant = (plant: Plant) => {
      setSelectedPlant(plant);
      setCurrentView('IDENTIFY');
  };

  const handleHistorySelect = (item: ScanHistoryItem) => {
      const tempPlant: Plant = {
          id: item.id,
          name: item.result.name,
          scientificName: item.result.scientificName,
          imageUrl: item.imageUrl,
          healthStatus: item.result.healthStatus as any,
          diagnosis: item.result.diagnosis,
          careInstructions: item.result.careTips,
          confidence: item.result.confidence,
          soilType: item.result.soilType,
          lightRequirements: item.result.lightRequirements,
          waterFrequency: item.result.waterFrequency,
          toxicity: item.result.toxicity,
          funFact: item.result.funFact,
          dateAdded: item.timestamp,
          nextWatering: undefined, 
      };
      setSelectedPlant(tempPlant);
      setCurrentView('IDENTIFY');
  };

  const handleAddManualTask = (task: CareTask) => {
      setManualTasks(prev => [...prev, task]);
      alert("Task Scheduled!");
  };

  const handleDeleteTask = (taskId: string) => {
      setManualTasks(prev => prev.filter(t => t.id !== taskId));
  }

  useEffect(() => {
      if (currentView !== 'IDENTIFY') {
          setSelectedPlant(null);
      }
  }, [currentView]);

  const renderView = () => {
    switch (currentView) {
      case 'HOME':
        return <HomeView 
            plants={plants} 
            history={history}
            onAddPlant={() => setCurrentView('IDENTIFY')} 
            onNavigateHistory={() => setCurrentView('IDENTIFY')}
            onSelectPlant={handleSelectPlant}
            onSelectHistoryItem={handleHistorySelect}
        />;
      case 'IDENTIFY':
        return <IdentifyView 
            onSavePlant={handleAddPlant} 
            language={language} 
            setLanguage={setLanguage}
            history={history}
            addToHistory={handleAddToHistory}
            initialPlant={selectedPlant}
        />;
      case 'CARE':
        return <CareView 
            plants={plants} 
            manualTasks={manualTasks}
            onAddManualTask={handleAddManualTask}
            onDeleteTask={handleDeleteTask}
        />;
      case 'EXPLORE':
        return <ExploreView language={language} />;
      case 'PROFILE':
        return (
             <div className="p-8 text-center pt-24">
            <h2 className="text-2xl font-display font-bold mb-4">Operator Profile</h2>
            <div className="glass-panel p-6 rounded-2xl text-left space-y-4">
               <div className="flex items-center space-x-4">
                   <div className="w-16 h-16 rounded-full bg-slate-700 flex items-center justify-center text-2xl">👨‍🚀</div>
                   <div>
                       <h3 className="font-bold text-lg">Commander User</h3>
                       <p className="text-sm text-slate-400">Level 5 Botanist</p>
                   </div>
               </div>
               <hr className="border-white/10" />
               <div className="space-y-4">
                   <div className="flex justify-between items-center text-sm">
                       <span>Language</span>
                        <select 
                            value={language}
                            onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                            className="bg-slate-900 text-neon-green border border-neon-green/30 rounded px-2 py-1"
                        >
                            <option value="en">English</option>
                            <option value="hi">हिन्दी</option>
                            <option value="ne">नेपाली</option>
                        </select>
                   </div>
                   <div className="flex justify-between text-sm">
                       <span>Subscription</span>
                       <span className="text-neon-green">Active (Rs. 500/mo)</span>
                   </div>
                   <div className="pt-4 flex justify-between">
                       <button 
                         onClick={() => {
                             if(confirm("Clear all data?")) {
                                 localStorage.clear();
                                 setPlants([]);
                                 setHistory([]);
                                 setManualTasks([]);
                                 setAppStage('AUTH');
                             }
                         }}
                         className="text-red-500 text-xs hover:underline"
                       >
                           Reset System
                       </button>
                        <button 
                         onClick={handleLogout}
                         className="text-slate-400 text-xs hover:text-white underline"
                       >
                           Logout
                       </button>
                   </div>
               </div>
            </div>
          </div>
        );
      default:
        return <HomeView plants={plants} history={history} onAddPlant={() => setCurrentView('IDENTIFY')} onNavigateHistory={() => setCurrentView('IDENTIFY')} onSelectPlant={handleSelectPlant} onSelectHistoryItem={handleHistorySelect} />;
    }
  };

  return (
    <div className="min-h-screen text-slate-100 font-sans selection:bg-neon-green selection:text-black bg-[#0f172a]">
       {/* Background Effects */}
       <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden">
           <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-900/20 rounded-full blur-[100px]"></div>
           <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-900/20 rounded-full blur-[100px]"></div>
       </div>

      {appStage === 'AUTH' && <AuthView onSuccess={handleAuthSuccess} />}
      
      {appStage === 'PAYMENT' && <PaymentView onPaymentSuccess={handlePaymentSuccess} onLogout={handleLogout} />}

      {appStage === 'APP' && (
        <>
            <main className="min-h-screen w-full pb-20">
                {renderView()}
            </main>
            <Navigation currentView={currentView} onNavigate={setCurrentView} />
        </>
      )}
    </div>
  );
};

export default App;