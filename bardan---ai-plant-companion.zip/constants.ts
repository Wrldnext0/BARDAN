export const APP_NAME = "Bardan";
export const VERSION = "1.0.0";
export const DEFAULT_LANGUAGE = "en";

// API Key is handled in geminiService via process.env
// Ensure you have a .env file or environment configuration with API_KEY
