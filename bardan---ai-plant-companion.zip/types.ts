
export type LanguageCode = 'en' | 'hi' | 'ne';

export interface Plant {
  id: string;
  name: string;
  scientificName?: string;
  imageUrl: string;
  healthStatus: 'Healthy' | 'Needs Attention' | 'Critical' | 'Unknown';
  diagnosis?: string;
  careInstructions?: string[];
  lastWatered?: Date;
  nextWatering?: Date;
  confidence?: number;
  // Enhanced Details
  soilType?: string;
  lightRequirements?: string;
  waterFrequency?: string;
  toxicity?: string;
  funFact?: string;
  dateAdded: Date;
  // PhD Level Analysis
  estimatedGrowthTime?: string;
  expertConsensus?: string;
  healthDetails?: {
      causes: string[];
      symptoms: string[];
      prevention: string[];
      treatment: string[];
  };
}

export interface UserSettings {
  language: LanguageCode;
  notifications: boolean;
}

export interface IdentifyResponse {
  name: string;
  scientificName: string;
  healthStatus: 'Healthy' | 'Needs Attention' | 'Critical';
  diagnosis: string;
  careTips: string[];
  confidence: number;
  // Enhanced Details
  soilType: string;
  lightRequirements: string;
  waterFrequency: string; // textual advice e.g. "Every 7 days"
  toxicity: string;
  funFact: string;
  // PhD Level Analysis
  estimatedGrowthTime: string;
  expertConsensus: string;
  healthDetails: {
      causes: string[];
      symptoms: string[];
      prevention: string[];
      treatment: string[];
  };
}

export type ViewState = 'HOME' | 'IDENTIFY' | 'CARE' | 'EXPLORE' | 'PROFILE';

export interface CareTask {
  id: string;
  plantId?: string; // Optional for general tasks
  plantName: string;
  type: string; // Changed to string to allow custom types like "Weeding"
  dueDate: Date;
  completed: boolean;
  isManual?: boolean;
}

export interface ScanHistoryItem {
  id: string;
  timestamp: Date;
  imageUrl: string;
  result: IdentifyResponse;
}
