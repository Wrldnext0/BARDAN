import React, { useState } from 'react';
import { Plant, CareTask } from '../types';

interface CareViewProps {
  plants: Plant[];
  manualTasks?: CareTask[];
  onAddManualTask?: (task: CareTask) => void;
  onDeleteTask?: (taskId: string) => void;
}

const CareView: React.FC<CareViewProps> = ({ plants, manualTasks = [], onAddManualTask, onDeleteTask }) => {
  const [activeTab, setActiveTab] = useState<'TASKS' | 'PLANTS'>('PLANTS');
  const [expandedPlant, setExpandedPlant] = useState<string | null>(null);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTask, setNewTask] = useState({ name: '', type: 'General', date: '' });

  // Generate automated tasks from plants
  const automatedTasks: CareTask[] = plants.flatMap((plant) => {
      return [{
          id: `${plant.id}-water`,
          plantId: plant.id,
          plantName: plant.name,
          type: 'Watering Reminder',
          dueDate: plant.nextWatering || new Date(),
          completed: false,
          isManual: false
      }];
  });

  // Merge and sort tasks
  const allTasks = [...automatedTasks, ...manualTasks].sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime());

  const handleCreateTask = () => {
      if (!newTask.name || !newTask.date) return alert("Please fill all fields");
      
      const task: CareTask = {
          id: Date.now().toString(),
          plantName: newTask.name,
          type: newTask.type,
          dueDate: new Date(newTask.date),
          completed: false,
          isManual: true
      };
      
      if (onAddManualTask) onAddManualTask(task);
      setIsAddingTask(false);
      setNewTask({ name: '', type: 'General', date: '' });
  };

  return (
    <div className="pb-24 pt-4 px-4 max-w-2xl mx-auto">
      <header className="mb-6">
        <h1 className="text-3xl font-display font-bold text-white tracking-wide">MAINTENANCE</h1>
        <p className="text-neon-purple text-sm font-sans tracking-widest uppercase">Care Protocols</p>
      </header>

      {/* Toggle */}
      <div className="flex bg-slate-800 p-1 rounded-lg mb-6">
          <button 
            onClick={() => setActiveTab('PLANTS')}
            className={`flex-1 py-2 rounded-md text-sm font-bold transition ${activeTab === 'PLANTS' ? 'bg-neon-purple text-white shadow-lg' : 'text-slate-400'}`}
          >
              Plant Profiles
          </button>
          <button 
            onClick={() => setActiveTab('TASKS')}
            className={`flex-1 py-2 rounded-md text-sm font-bold transition ${activeTab === 'TASKS' ? 'bg-neon-purple text-white shadow-lg' : 'text-slate-400'}`}
          >
              Schedule
          </button>
      </div>

      {activeTab === 'TASKS' && (
           <div className="space-y-4">
               {/* Add Task Button */}
               {!isAddingTask ? (
                   <button 
                    onClick={() => setIsAddingTask(true)}
                    className="w-full py-3 border border-dashed border-slate-600 rounded-xl text-slate-400 hover:text-white hover:border-white transition flex items-center justify-center space-x-2"
                   >
                       <span>+ Schedule Custom Task</span>
                   </button>
               ) : (
                   <div className="glass-panel p-4 rounded-xl space-y-3 border border-neon-purple/50">
                       <h3 className="text-white font-bold text-sm uppercase">New Task</h3>
                       <input 
                         type="text" 
                         placeholder="Task Name (e.g. Weeding, Grubbing)" 
                         className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white text-sm focus:border-neon-purple outline-none"
                         value={newTask.type}
                         onChange={(e) => setNewTask({...newTask, type: e.target.value})}
                       />
                       <input 
                         type="text" 
                         placeholder="Plant or Area Name" 
                         className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white text-sm focus:border-neon-purple outline-none"
                         value={newTask.name}
                         onChange={(e) => setNewTask({...newTask, name: e.target.value})}
                       />
                       <input 
                         type="date" 
                         className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white text-sm focus:border-neon-purple outline-none"
                         value={newTask.date}
                         onChange={(e) => setNewTask({...newTask, date: e.target.value})}
                       />
                       <div className="flex space-x-2">
                           <button onClick={handleCreateTask} className="flex-1 bg-neon-purple text-white py-2 rounded font-bold text-sm">Save</button>
                           <button onClick={() => setIsAddingTask(false)} className="flex-1 bg-slate-700 text-white py-2 rounded font-bold text-sm">Cancel</button>
                       </div>
                   </div>
               )}

            {allTasks.length === 0 ? (
                    <div className="text-center py-12 glass-panel rounded-3xl">
                        <p className="text-slate-500">All systems nominal. No pending tasks.</p>
                    </div>
                ) : (
                    allTasks.map(task => (
                        <div key={task.id} className="glass-panel p-4 rounded-xl flex items-center justify-between group border-l-4 border-l-neon-purple hover:bg-white/5 transition">
                            <div className="flex items-center space-x-4">
                                <div className="bg-slate-800 p-3 rounded-lg text-neon-purple">
                                    {task.type.toLowerCase().includes('water') ? (
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                                        </svg>
                                    ) : (
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                        </svg>
                                    )}
                                </div>
                                <div>
                                    <h3 className="font-bold text-white text-lg">{task.type}</h3>
                                    <p className="text-sm text-slate-300">{task.plantName}</p>
                                    <p className="text-xs text-slate-500">Due: {task.dueDate.toLocaleDateString()}</p>
                                </div>
                            </div>
                            {task.isManual && onDeleteTask && (
                                <button 
                                    onClick={() => onDeleteTask(task.id)}
                                    className="text-red-500 hover:text-red-400 p-2"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                                    </svg>
                                </button>
                            )}
                        </div>
                    ))
                )}
           </div>
      )}

      {activeTab === 'PLANTS' && (
          <div className="space-y-4">
               {plants.length === 0 ? (
                   <div className="text-center text-slate-500 py-10">
                       <p>No plants in collection.</p>
                   </div>
               ) : plants.map(plant => (
                   <div key={plant.id} className="glass-panel rounded-2xl overflow-hidden border border-white/5">
                       <div 
                        onClick={() => setExpandedPlant(expandedPlant === plant.id ? null : plant.id)}
                        className="p-4 flex items-center space-x-4 cursor-pointer hover:bg-white/5 transition"
                       >
                           <img src={plant.imageUrl} className="w-16 h-16 rounded-lg object-cover" />
                           <div className="flex-1">
                               <h3 className="font-bold text-lg text-white">{plant.name}</h3>
                               <p className="text-xs text-slate-400 italic">{plant.scientificName}</p>
                           </div>
                           <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 text-slate-500 transition-transform ${expandedPlant === plant.id ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                           </svg>
                       </div>
                       
                       {expandedPlant === plant.id && (
                           <div className="px-4 pb-4 pt-0 bg-slate-900/50 border-t border-white/5">
                               <div className="grid grid-cols-2 gap-3 mt-4">
                                   <div className="bg-slate-800 p-3 rounded-lg">
                                       <p className="text-[10px] text-slate-500 uppercase font-bold">Light</p>
                                       <p className="text-xs text-slate-200 mt-1">{plant.lightRequirements || 'Unknown'}</p>
                                   </div>
                                   <div className="bg-slate-800 p-3 rounded-lg">
                                       <p className="text-[10px] text-slate-500 uppercase font-bold">Water</p>
                                       <p className="text-xs text-slate-200 mt-1">{plant.waterFrequency || 'Weekly'}</p>
                                   </div>
                                    <div className="bg-slate-800 p-3 rounded-lg">
                                       <p className="text-[10px] text-slate-500 uppercase font-bold">Soil</p>
                                       <p className="text-xs text-slate-200 mt-1">{plant.soilType || 'Standard Potting Mix'}</p>
                                   </div>
                                   <div className="bg-slate-800 p-3 rounded-lg">
                                       <p className="text-[10px] text-slate-500 uppercase font-bold">Toxicity</p>
                                       <p className="text-xs text-slate-200 mt-1">{plant.toxicity || 'Unknown'}</p>
                                   </div>
                               </div>
                               <div className="mt-4">
                                   <p className="text-[10px] text-slate-500 uppercase font-bold mb-2">Care Tips</p>
                                   <ul className="space-y-1">
                                       {plant.careInstructions?.map((tip, i) => (
                                           <li key={i} className="text-xs text-slate-300 flex items-start">
                                               <span className="mr-2 text-neon-purple">•</span> {tip}
                                           </li>
                                       ))}
                                   </ul>
                               </div>
                           </div>
                       )}
                   </div>
               ))}
          </div>
      )}

    </div>
  );
};

export default CareView;