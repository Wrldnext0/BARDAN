import React, { useState } from 'react';
import { exploreLocalFlora } from '../services/geminiService';
import { LanguageCode } from '../types';

interface ExploreViewProps {
  language: LanguageCode;
}

const ExploreView: React.FC<ExploreViewProps> = ({ language }) => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [coords, setCoords] = useState<{lat: number, long: number} | null>(null);

  const t = {
    en: {
        title: 'PLANETARY SCAN',
        subtitle: 'Local Ecosystem Analysis',
        scanBtn: 'Scan Local Sector',
        scanning: 'Triangulating Position...',
        analyzing: 'Analyzing Biome...',
        permission: 'Location permission required for scan.',
        error: 'Scan Failed.'
    },
    hi: {
        title: 'ग्रहीय स्कैन',
        subtitle: 'स्थानीय पारिस्थितिकी तंत्र',
        scanBtn: 'स्थानीय क्षेत्र स्कैन करें',
        scanning: 'स्थान का पता लगाया जा रहा है...',
        analyzing: 'बायोम का विश्लेषण...',
        permission: 'स्कैन के लिए स्थान की अनुमति आवश्यक है।',
        error: 'स्कैन विफल।'
    },
    ne: {
        title: 'ग्रह स्क्यान',
        subtitle: 'स्थानीय पारिस्थितिकी प्रणाली',
        scanBtn: 'स्थानीय क्षेत्र स्क्यान गर्नुहोस्',
        scanning: 'स्थान पत्ता लगाउँदै...',
        analyzing: 'बायोम विश्लेषण गर्दै...',
        permission: 'स्क्यानका लागि स्थान अनुमति आवश्यक छ।',
        error: 'स्क्यान असफल।'
    }
  }[language];

  const handleScan = () => {
    if (!navigator.geolocation) {
        alert("Geolocation is not supported by this browser. Please use a device with GPS.");
        return;
    }

    setLoading(true);
    setErrorMsg(null);
    setData(null);

    navigator.geolocation.getCurrentPosition(
        async (position) => {
            const { latitude, longitude } = position.coords;
            setCoords({ lat: latitude, long: longitude });
            
            try {
                const result = await exploreLocalFlora(latitude, longitude, language);
                setData(result);
            } catch (e: any) {
                console.error("Explore execution failed", e);
                setErrorMsg(e.message || t.error);
                setData(null);
            } finally {
                setLoading(false);
            }
        },
        (error) => {
            console.error("Geolocation error", error);
            setErrorMsg(`Location Error: ${error.message}. Please enable location services.`);
            setLoading(false);
        },
        { timeout: 10000, enableHighAccuracy: false } // Options to make it more robust
    );
  };

  return (
    <div className="pb-24 pt-4 px-4 max-w-2xl mx-auto h-full flex flex-col">
       <header className="mb-6">
        <h1 className="text-3xl font-display font-bold text-white tracking-wide">{t.title}</h1>
        <p className="text-neon-blue text-sm font-sans tracking-widest uppercase">{t.subtitle}</p>
      </header>

      <div className="flex-1 flex flex-col items-center justify-center space-y-6">
          {!data && !loading && !errorMsg && (
             <div className="text-center space-y-4">
                 <div className="w-32 h-32 rounded-full border border-neon-blue/30 flex items-center justify-center mx-auto bg-neon-blue/5 animate-pulse">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-neon-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                 </div>
                 <button 
                    onClick={handleScan}
                    className="bg-neon-blue/10 border border-neon-blue text-neon-blue hover:bg-neon-blue hover:text-slate-900 px-8 py-3 rounded-full font-display font-bold uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(0,243,255,0.2)]"
                 >
                     {t.scanBtn}
                 </button>
             </div>
          )}

          {loading && (
             <div className="text-center space-y-4">
                  <div className="w-16 h-16 border-4 border-neon-blue border-t-transparent rounded-full animate-spin mx-auto"></div>
                  <p className="text-neon-blue font-mono text-sm animate-pulse">{coords ? t.analyzing : t.scanning}</p>
             </div>
          )}

          {errorMsg && (
              <div className="text-center space-y-4 p-6 glass-panel rounded-xl border-red-500/50 border">
                  <p className="text-red-400 font-bold">{errorMsg}</p>
                  <button onClick={handleScan} className="text-sm underline text-slate-400">Try Again</button>
              </div>
          )}

          {data && (
              <div className="w-full glass-panel p-6 rounded-2xl border border-neon-blue/30 space-y-4 max-h-[70vh] overflow-y-auto">
                   <div className="flex justify-between items-center border-b border-white/10 pb-4">
                        <div className="flex items-center space-x-2">
                             <span className="w-2 h-2 bg-neon-blue rounded-full animate-pulse"></span>
                             <span className="text-xs font-mono text-slate-400">
                                 LAT: {coords?.lat.toFixed(4)} | LNG: {coords?.long.toFixed(4)}
                             </span>
                        </div>
                        <button onClick={() => setData(null)} className="text-xs text-slate-500 hover:text-white uppercase">Clear</button>
                   </div>
                   <div className="prose prose-invert prose-sm max-w-none">
                       {data.split('\n').map((line, i) => (
                           <p key={i} className="text-slate-200 leading-relaxed">{line}</p>
                       ))}
                   </div>
              </div>
          )}
      </div>
    </div>
  );
};

export default ExploreView;