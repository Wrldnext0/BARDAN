import React, { useState, useRef, useEffect } from 'react';
import { identifyPlantWithGemini } from '../services/geminiService';
import { IdentifyResponse, Plant, LanguageCode, ScanHistoryItem } from '../types';

interface IdentifyViewProps {
  onSavePlant: (plant: Plant) => void;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  history: ScanHistoryItem[];
  addToHistory: (item: ScanHistoryItem) => void;
  initialPlant?: Plant | null;
}

const IdentifyView: React.FC<IdentifyViewProps> = ({ onSavePlant, language, setLanguage, history, addToHistory, initialPlant }) => {
  const [image, setImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<IdentifyResponse | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  
  // Camera Capabilities State
  const [hasFlash, setHasFlash] = useState(false);
  const [flashOn, setFlashOn] = useState(false);
  const [zoomSupported, setZoomSupported] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [maxZoom, setMaxZoom] = useState(1);
  const [track, setTrack] = useState<MediaStreamTrack | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load initial plant if provided (View Mode)
  useEffect(() => {
    if (initialPlant) {
        setImage(initialPlant.imageUrl);
        setResult({
            name: initialPlant.name,
            scientificName: initialPlant.scientificName || '',
            healthStatus: initialPlant.healthStatus === 'Unknown' ? 'Healthy' : initialPlant.healthStatus as any,
            diagnosis: initialPlant.diagnosis || '',
            careTips: initialPlant.careInstructions || [],
            confidence: initialPlant.confidence || 1,
            soilType: initialPlant.soilType || 'N/A',
            lightRequirements: initialPlant.lightRequirements || 'N/A',
            waterFrequency: initialPlant.waterFrequency || 'N/A',
            toxicity: initialPlant.toxicity || 'N/A',
            funFact: initialPlant.funFact || 'No data available.',
            // New fields mapping
            estimatedGrowthTime: initialPlant.estimatedGrowthTime || 'Analysis not available',
            expertConsensus: initialPlant.expertConsensus || 'Historic data does not contain consensus.',
            healthDetails: initialPlant.healthDetails || { causes: [], symptoms: [], prevention: [], treatment: [] }
        });
        setCameraActive(false);
        window.scrollTo(0, 0);
    }
  }, [initialPlant]);

  // Localization Dictionary
  const t = {
    en: {
      title: 'IDENTIFY',
      subtitle: 'Bio-Scan Interface',
      tapToScan: 'Tap to Scan',
      upload: 'Upload or Capture',
      analyze: 'Run Diagnostics',
      analyzing: 'Analyzing...',
      save: 'Add to Collection',
      retake: 'Retake',
      startCamera: 'Open Camera',
      stopCamera: 'Stop Camera',
      capture: 'Capture',
      recent: 'Recent Scans',
      details: 'Plant Details',
      soil: 'Soil',
      light: 'Light',
      water: 'Water',
      toxic: 'Toxicity',
      alreadySaved: 'View Only Mode',
      consensus: 'Global Intelligence Consensus',
      pathology: 'Pathology Report',
      growth: 'Growth Prediction'
    },
    hi: {
      title: 'पहचान करें',
      subtitle: 'बायो-स्कैन इंटरफ़ेस',
      tapToScan: 'स्कैन करने के लिए टैप करें',
      upload: 'अपलोड या फोटो लें',
      analyze: 'जांच शुरू करें',
      analyzing: 'विश्लेषण हो रहा है...',
      save: 'संग्रह में जोड़ें',
      retake: 'दोबारा लें',
      startCamera: 'कैमरा खोलें',
      stopCamera: 'कैमरा बंद करें',
      capture: 'फोटो लें',
      recent: 'हाल के स्कैन',
      details: 'पौधे का विवरण',
      soil: 'मिट्टी',
      light: 'धूप',
      water: 'पानी',
      toxic: 'विषाक्तता',
      alreadySaved: 'केवल देखें',
      consensus: 'वैश्विक विशेषज्ञ सहमति',
      pathology: 'रोग विज्ञान रिपोर्ट',
      growth: 'विकास भविष्यवाणी'
    },
    ne: {
      title: 'पहिचान गर्नुहोस्',
      subtitle: 'बायो-स्क्यान इन्टरफेस',
      tapToScan: 'स्क्यान गर्न ट्याप गर्नुहोस्',
      upload: 'अपलोड वा फोटो खिच्नुहोस्',
      analyze: 'निदान चलाउनुहोस्',
      analyzing: 'विश्लेषण हुँदैछ...',
      save: 'संग्रहमा थप्नुहोस्',
      retake: 'फेरी खिच्नुहोस्',
      startCamera: 'क्यामेरा खोल्नुहोस्',
      stopCamera: 'क्यामेरा बन्द गर्नुहोस्',
      capture: 'खिच्नुहोस्',
      recent: 'हालका स्क्यानहरू',
      details: 'बिरुवाको विवरण',
      soil: 'माटो',
      light: 'प्रकाश',
      water: 'पानी',
      toxic: 'विषाक्तता',
      alreadySaved: 'हेर्ने मात्र',
      consensus: 'विश्वव्यापी विशेषज्ञ सहमति',
      pathology: 'रोग विज्ञान रिपोर्ट',
      growth: 'वृद्धि भविष्यवाणी'
    }
  }[language];

  // Camera Logic
  const startCamera = async () => {
    setCameraActive(true);
    setImage(null);
    setResult(null);
    try {
      const constraints = { 
        video: { 
            facingMode: 'environment',
            width: { ideal: 1920 }, // Request high res for better AI analysis
            height: { ideal: 1080 },
            focusMode: 'continuous' // Attempt to force continuous focus
        } 
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      // Analyze Capabilities
      const videoTrack = stream.getVideoTracks()[0];
      setTrack(videoTrack);

      // Check capabilities (Chrome/Android specific mostly)
      if ('getCapabilities' in videoTrack) {
          const capabilities = (videoTrack as any).getCapabilities();
          
          // Check for Torch/Flash
          if (capabilities.torch) {
              setHasFlash(true);
          }

          // Check for Zoom
          if (capabilities.zoom) {
              setZoomSupported(true);
              setMaxZoom(capabilities.zoom.max);
              setZoomLevel(capabilities.zoom.min || 1);
          }
      }

    } catch (err) {
      console.error("Camera Error:", err);
      alert("Camera access denied or unavailable.");
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => {
          track.stop();
          // Turn off flash if it was on
          if (flashOn) {
              try { (track as any).applyConstraints({ advanced: [{ torch: false }] }); } catch(e){}
          }
      });
    }
    setCameraActive(false);
    setFlashOn(false);
    setTrack(null);
  };

  const toggleFlash = async () => {
      if (!track || !hasFlash) return;
      const newFlashState = !flashOn;
      try {
          await (track as any).applyConstraints({
              advanced: [{ torch: newFlashState }]
          });
          setFlashOn(newFlashState);
      } catch (e) {
          console.error("Flash error", e);
      }
  };

  const handleZoom = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const value = parseFloat(e.target.value);
      setZoomLevel(value);
      if (track && zoomSupported) {
          try {
              await (track as any).applyConstraints({
                  advanced: [{ zoom: value }]
              });
          } catch (e) {
              console.error("Zoom error", e);
          }
      }
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setImage(dataUrl);
        stopCamera();
      }
    }
  };

  useEffect(() => {
    return () => stopCamera(); // Cleanup on unmount
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (ev) => {
        setImage(ev.target?.result as string);
        setResult(null);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleScan = async () => {
    if (!image) return;
    setAnalyzing(true);
    try {
      const analysis = await identifyPlantWithGemini(image, language);
      setResult(analysis);
      addToHistory({
          id: Date.now().toString(),
          timestamp: new Date(),
          imageUrl: image,
          result: analysis
      });

    } catch (error: any) {
      let errorMessage = "Unknown error occurred.";
      if (error && typeof error === 'object' && error.message) {
          errorMessage = error.message;
      } else if (typeof error === 'string') {
          errorMessage = error;
      } else {
          errorMessage = JSON.stringify(error);
      }
      alert("Analysis Failed: " + errorMessage);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSave = () => {
    if (result && image && !initialPlant) {
      const newPlant: Plant = {
        id: Date.now().toString(),
        name: String(result.name),
        scientificName: String(result.scientificName),
        imageUrl: image,
        healthStatus: result.healthStatus as any,
        diagnosis: String(result.diagnosis),
        careInstructions: result.careTips.map(String),
        confidence: Number(result.confidence),
        soilType: String(result.soilType),
        lightRequirements: String(result.lightRequirements),
        waterFrequency: String(result.waterFrequency),
        toxicity: String(result.toxicity),
        funFact: String(result.funFact),
        nextWatering: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Default 7 days
        dateAdded: new Date(),
        estimatedGrowthTime: result.estimatedGrowthTime,
        expertConsensus: result.expertConsensus,
        healthDetails: result.healthDetails
      };
      onSavePlant(newPlant);
    }
  };

  const loadHistoryItem = (item: ScanHistoryItem) => {
      setImage(item.imageUrl);
      setResult(item.result);
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderValue = (val: any) => {
      if (typeof val === 'string') return val;
      if (typeof val === 'number') return val.toString();
      return 'N/A';
  }

  return (
    <div className="pb-24 pt-4 px-4 max-w-2xl mx-auto h-full flex flex-col">
       <header className="mb-6 flex justify-between items-end">
        <div>
            <h1 className="text-3xl font-display font-bold text-white tracking-wide">{t.title}</h1>
            <p className="text-neon-blue text-sm font-sans tracking-widest uppercase">{t.subtitle}</p>
        </div>
        <select 
            value={language}
            onChange={(e) => setLanguage(e.target.value as LanguageCode)}
            className="bg-slate-800 text-neon-green border border-neon-green/30 rounded-lg px-2 py-1 text-sm font-display focus:outline-none"
        >
            <option value="en">English</option>
            <option value="hi">हिन्दी</option>
            <option value="ne">नेपाली</option>
        </select>
      </header>

      <div className="flex-1 flex flex-col items-center justify-start space-y-6 w-full">
        
        {/* Camera/Image Area */}
        <div className="relative w-full aspect-[3/4] max-w-sm rounded-3xl overflow-hidden glass-panel border-2 border-dashed border-slate-600 flex flex-col items-center justify-center group bg-black transition-all duration-300">
          {cameraActive ? (
             <>
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                
                {/* AI HUD Overlay */}
                <div className="absolute inset-0 pointer-events-none">
                    {/* Scanner Line */}
                    <div className="absolute top-0 left-0 w-full h-1 bg-neon-green/50 shadow-[0_0_15px_#00ff9d] animate-[pulse-slow_3s_ease-in-out_infinite] top-[50%]"></div>
                    
                    {/* Corners */}
                    <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-neon-green/70 rounded-tl-lg"></div>
                    <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-neon-green/70 rounded-tr-lg"></div>
                    <div className="absolute bottom-24 left-4 w-8 h-8 border-b-2 border-l-2 border-neon-green/70 rounded-bl-lg"></div>
                    <div className="absolute bottom-24 right-4 w-8 h-8 border-b-2 border-r-2 border-neon-green/70 rounded-br-lg"></div>
                    
                    {/* Status Text */}
                    <div className="absolute top-6 left-1/2 transform -translate-x-1/2 bg-black/40 backdrop-blur-sm px-3 py-1 rounded-full border border-white/10">
                        <p className="text-[10px] text-neon-blue font-mono tracking-widest uppercase animate-pulse">AI VISION ACTIVE</p>
                    </div>
                </div>

                {/* Camera Controls */}
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent pt-10">
                    {/* Zoom Slider */}
                    {zoomSupported && (
                        <div className="flex items-center space-x-3 mb-4 px-2">
                             <span className="text-[10px] text-white font-mono">1x</span>
                             <input 
                                type="range" 
                                min="1" 
                                max={maxZoom} 
                                step="0.1" 
                                value={zoomLevel} 
                                onChange={handleZoom}
                                className="w-full h-1 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-neon-green"
                             />
                             <span className="text-[10px] text-white font-mono">{zoomLevel.toFixed(1)}x</span>
                        </div>
                    )}
                    
                    <div className="flex justify-between items-center px-4">
                        {/* Flash Toggle */}
                        {hasFlash ? (
                            <button 
                                onClick={toggleFlash}
                                className={`p-3 rounded-full border ${flashOn ? 'bg-yellow-400/20 border-yellow-400 text-yellow-400' : 'bg-slate-800/50 border-white/20 text-white'}`}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={flashOn ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                                </svg>
                            </button>
                        ) : (
                            <div className="w-12"></div> // Spacer
                        )}

                        {/* Shutter Button */}
                        <button 
                            onClick={captureImage}
                            className="w-16 h-16 bg-white rounded-full border-4 border-slate-300 shadow-[0_0_20px_white] hover:scale-105 transition active:scale-95 relative"
                        >
                            <div className="absolute inset-1 rounded-full border border-black/10"></div>
                        </button>

                         {/* Close Camera */}
                        <button 
                             onClick={stopCamera}
                             className="p-3 bg-red-500/20 rounded-full border border-red-500/50 text-red-500 hover:bg-red-500 hover:text-white transition"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                </div>
             </>
          ) : image ? (
            <>
                <img src={image} alt="Preview" className="w-full h-full object-cover" />
                <button 
                    onClick={() => { setImage(null); setResult(null); }}
                    className="absolute top-4 right-4 bg-black/50 p-2 rounded-full text-white backdrop-blur-md hover:bg-red-500/50 transition"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                </button>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center w-full h-full space-y-4">
                <button 
                    onClick={startCamera}
                    className="bg-neon-green/10 hover:bg-neon-green/20 text-neon-green px-8 py-4 rounded-full font-bold font-display uppercase tracking-wider transition border border-neon-green shadow-[0_0_15px_rgba(0,255,157,0.2)] flex items-center space-x-2"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <span>{t.startCamera}</span>
                </button>
                <div className="flex items-center space-x-3">
                    <div className="h-px w-10 bg-slate-700"></div>
                    <p className="text-slate-500 text-xs uppercase tracking-widest">System Ready</p>
                     <div className="h-px w-10 bg-slate-700"></div>
                </div>
                <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="cursor-pointer text-slate-400 hover:text-white text-sm flex items-center space-x-1"
                >
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                    </svg>
                   <span className="underline">{t.upload}</span>
                </div>
            </div>
          )}
          
          <input 
            type="file" 
            ref={fileInputRef}
            className="hidden" 
            accept="image/*" 
            onChange={handleFileChange}
          />
          <canvas ref={canvasRef} className="hidden" />
        </div>

        {/* Action Button */}
        {image && !result && (
          <button
            onClick={handleScan}
            disabled={analyzing}
            className="w-full max-w-sm bg-neon-green text-slate-900 font-bold font-display py-4 rounded-xl uppercase tracking-widest hover:bg-white transition-all shadow-[0_0_20px_rgba(0,255,157,0.4)] disabled:opacity-50 flex items-center justify-center"
          >
            {analyzing ? (
               <>
                 <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-slate-900" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                   <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                   <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                 </svg>
                 {t.analyzing}
               </>
            ) : (
                t.analyze
            )}
          </button>
        )}

        {/* Results - Background black for clarity */}
        {result && (
          <div className="w-full max-w-sm bg-black border border-slate-800 p-6 rounded-2xl space-y-4 transition-all duration-500 ease-in-out shadow-[0_0_50px_rgba(0,0,0,0.8)] z-10 relative">
            
            {/* Header / ID */}
            <div className="flex justify-between items-start">
               <div>
                 <h2 className="text-2xl font-display font-bold text-neon-green">{renderValue(result.name)}</h2>
                 <p className="text-slate-400 italic text-sm">{renderValue(result.scientificName)}</p>
               </div>
               <div className="bg-slate-800 px-3 py-1 rounded-full border border-white/10">
                   <span className="text-xs text-neon-blue font-mono">{Math.round(result.confidence * 100)}% Match</span>
               </div>
            </div>

            <div className={`p-3 rounded-lg border ${
                result.healthStatus === 'Healthy' ? 'bg-green-900/40 border-green-500/30' : 
                result.healthStatus === 'Critical' ? 'bg-red-900/40 border-red-500/30' : 'bg-yellow-900/40 border-yellow-500/30'
            }`}>
                 <div className="flex items-center space-x-2 mb-1">
                    <div className={`w-2 h-2 rounded-full ${
                        result.healthStatus === 'Healthy' ? 'bg-green-500' : 
                        result.healthStatus === 'Critical' ? 'bg-red-500' : 'bg-yellow-500'
                    }`}></div>
                    <span className="font-bold uppercase text-xs tracking-wider text-white">{renderValue(result.healthStatus)}</span>
                 </div>
                 <p className="text-sm text-slate-200">{renderValue(result.diagnosis)}</p>
            </div>

            {/* Expert Consensus - "10 Lakhs PHD" */}
            <div className="bg-slate-900/50 p-4 rounded-xl border border-neon-blue/30 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-8 h-8 bg-neon-blue/20 blur-xl"></div>
                <h3 className="text-xs uppercase text-neon-blue font-bold tracking-widest mb-2 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                    </svg>
                    {t.consensus}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed italic border-l-2 border-neon-blue pl-3">
                    {renderValue(result.expertConsensus)}
                </p>
            </div>

            {/* Growth Prediction */}
             <div className="bg-slate-900/50 p-3 rounded-xl border border-white/5 flex items-center space-x-3">
                 <div className="p-2 bg-purple-900/30 rounded-lg text-neon-purple">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                 </div>
                 <div>
                     <h3 className="text-[10px] uppercase text-slate-500 font-bold tracking-wider">{t.growth}</h3>
                     <p className="text-sm text-white">{renderValue(result.estimatedGrowthTime)}</p>
                 </div>
            </div>

            {/* Detailed Pathology Report */}
            {result.healthDetails && (
                <div className="space-y-3">
                    <h3 className="text-xs uppercase text-slate-500 font-bold tracking-wider border-b border-white/10 pb-1">{t.pathology}</h3>
                    
                    {/* Grid for Causes/Symptoms */}
                    <div className="grid grid-cols-2 gap-3">
                        <div className="bg-red-900/20 p-3 rounded-lg border border-red-500/20">
                            <span className="text-[10px] text-red-400 font-bold uppercase block mb-1">Symptoms</span>
                            <ul className="list-disc list-inside">
                                {result.healthDetails.symptoms.length > 0 ? (
                                    result.healthDetails.symptoms.map((s, i) => <li key={i} className="text-[10px] text-slate-300">{s}</li>)
                                ) : <li className="text-[10px] text-slate-500">None detected</li>}
                            </ul>
                        </div>
                         <div className="bg-orange-900/20 p-3 rounded-lg border border-orange-500/20">
                            <span className="text-[10px] text-orange-400 font-bold uppercase block mb-1">Potential Causes</span>
                             <ul className="list-disc list-inside">
                                {result.healthDetails.causes.length > 0 ? (
                                    result.healthDetails.causes.map((s, i) => <li key={i} className="text-[10px] text-slate-300">{s}</li>)
                                ) : <li className="text-[10px] text-slate-500">Unknown</li>}
                            </ul>
                        </div>
                    </div>

                    {/* Prevention & Cure */}
                    <div className="bg-green-900/20 p-3 rounded-lg border border-green-500/20">
                        <span className="text-[10px] text-green-400 font-bold uppercase block mb-1">Cure & Treatment</span>
                        <ul className="space-y-1">
                             {result.healthDetails.treatment.length > 0 ? (
                                result.healthDetails.treatment.map((s, i) => (
                                    <li key={i} className="text-[11px] text-slate-200 flex items-start">
                                        <span className="text-green-500 mr-2">✚</span> {s}
                                    </li>
                                ))
                            ) : <li className="text-[10px] text-slate-500">No treatment required</li>}
                        </ul>
                    </div>
                     <div className="bg-blue-900/20 p-3 rounded-lg border border-blue-500/20">
                        <span className="text-[10px] text-blue-400 font-bold uppercase block mb-1">Prevention Strategy</span>
                         <ul className="space-y-1">
                             {result.healthDetails.prevention.length > 0 ? (
                                result.healthDetails.prevention.map((s, i) => (
                                    <li key={i} className="text-[11px] text-slate-200 flex items-start">
                                        <span className="text-blue-500 mr-2">🛡</span> {s}
                                    </li>
                                ))
                            ) : <li className="text-[10px] text-slate-500">Maintain current care</li>}
                        </ul>
                    </div>
                </div>
            )}

            {/* Basic Details Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-white/10">
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 block uppercase text-[10px]">{t.soil}</span>
                    <span className="text-slate-200">{renderValue(result.soilType)}</span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 block uppercase text-[10px]">{t.light}</span>
                    <span className="text-slate-200">{renderValue(result.lightRequirements)}</span>
                </div>
                 <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 block uppercase text-[10px]">{t.water}</span>
                    <span className="text-slate-200">{renderValue(result.waterFrequency)}</span>
                </div>
                 <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 block uppercase text-[10px]">{t.toxic}</span>
                    <span className="text-slate-200">{renderValue(result.toxicity)}</span>
                </div>
            </div>
            
            <div className="bg-neon-purple/10 border border-neon-purple/20 p-3 rounded-lg">
                 <p className="text-xs text-neon-purple italic">" {renderValue(result.funFact)} "</p>
            </div>

            {/* Hide Save button if viewing saved plant */}
            {!initialPlant ? (
                 <button
                    onClick={handleSave}
                    className="w-full border border-neon-green text-neon-green py-3 rounded-xl font-display font-bold uppercase hover:bg-neon-green hover:text-slate-900 transition-colors"
                >
                    {t.save}
                </button>
            ) : (
                <div className="text-center">
                    <span className="text-xs text-slate-500 uppercase tracking-widest">{t.alreadySaved}</span>
                </div>
            )}
           
          </div>
        )}

        {/* History Section - Always Visible if no active analysis */}
        {!image && history.length > 0 && (
            <div className="w-full max-w-sm mt-8 pb-4">
                <h3 className="text-slate-500 text-sm font-bold uppercase tracking-wider mb-4 border-b border-white/10 pb-2">{t.recent}</h3>
                <div className="space-y-2">
                    {history.slice().reverse().map(item => (
                        <div 
                            key={item.id} 
                            onClick={() => loadHistoryItem(item)}
                            className="glass-panel p-3 rounded-lg flex items-center space-x-4 cursor-pointer hover:bg-white/10 transition active:scale-[0.98]"
                        >
                            <img src={item.imageUrl} className="w-16 h-16 rounded-md object-cover border border-white/10" />
                            <div className="flex-1">
                                <div className="flex justify-between items-start">
                                    <h4 className="font-bold text-sm text-white">{renderValue(item.result.name)}</h4>
                                     <div className={`w-2 h-2 rounded-full mt-1 ${
                                        item.result.healthStatus === 'Healthy' ? 'bg-neon-green' : 'bg-red-500'
                                    }`} />
                                </div>
                                <p className="text-xs text-slate-400 mt-1 line-clamp-2">{renderValue(item.result.diagnosis)}</p>
                                <p className="text-[10px] text-slate-500 mt-2">{new Date(item.timestamp).toLocaleDateString()}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        )}

      </div>
    </div>
  );
};

export default IdentifyView;