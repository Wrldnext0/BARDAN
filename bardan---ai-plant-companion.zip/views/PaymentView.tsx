import React, { useState } from 'react';

interface PaymentViewProps {
  onPaymentSuccess: () => void;
  onLogout: () => void;
}

const PaymentView: React.FC<PaymentViewProps> = ({ onPaymentSuccess, onLogout }) => {
  const [processing, setProcessing] = useState<string | null>(null);

  const gateways = [
      { id: 'stripe', name: 'Stripe', color: 'bg-indigo-600' },
      { id: 'paypal', name: 'PayPal', color: 'bg-blue-700' },
      { id: 'upi', name: 'UPI', color: 'bg-orange-600' },
      { id: 'esewa', name: 'eSewa', color: 'bg-green-600' },
      { id: 'khalti', name: 'Khalti', color: 'bg-purple-700' },
      { id: 'fonepay', name: 'Fonepay', color: 'bg-red-600' },
  ];

  const handlePayment = (gatewayName: string) => {
      setProcessing(gatewayName);
      // Simulate API call
      setTimeout(() => {
          localStorage.setItem('bardan_subscription', 'active');
          onPaymentSuccess();
      }, 2000);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative">
         <div className="w-full max-w-sm glass-panel p-8 rounded-3xl border border-yellow-500/30 relative z-10 text-center">
             
             <div className="w-16 h-16 rounded-full bg-yellow-500/10 border border-yellow-500 flex items-center justify-center mx-auto mb-6">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                 </svg>
             </div>

             <h2 className="text-2xl font-display font-bold text-white mb-2">SUBSCRIPTION REQUIRED</h2>
             <p className="text-slate-400 text-sm mb-6">Access to the Bardan AI network requires a monthly contribution.</p>

             <div className="bg-slate-900/80 p-4 rounded-xl mb-6 border border-slate-700">
                 <p className="text-xs text-slate-500 uppercase tracking-widest mb-1">Total Due</p>
                 <p className="text-3xl font-mono font-bold text-neon-green">Rs. 500<span className="text-sm text-slate-500">/mo</span></p>
             </div>

             <div className="grid grid-cols-2 gap-3 mb-6">
                 {gateways.map(gw => (
                     <button
                        key={gw.id}
                        disabled={!!processing}
                        onClick={() => handlePayment(gw.name)}
                        className={`${gw.color} hover:brightness-110 text-white font-bold py-3 px-2 rounded-lg text-sm shadow-lg transition-transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed`}
                     >
                         {processing === gw.name ? 'Processing...' : gw.name}
                     </button>
                 ))}
             </div>

             <button 
                onClick={onLogout}
                className="text-xs text-red-500 hover:text-red-400 underline"
             >
                 Cancel Session & Logout
             </button>
         </div>
    </div>
  );
};

export default PaymentView;