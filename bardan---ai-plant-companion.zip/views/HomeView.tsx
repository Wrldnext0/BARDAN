import React from 'react';
import { Plant, ScanHistoryItem } from '../types';

interface HomeViewProps {
  plants: Plant[];
  history: ScanHistoryItem[];
  onAddPlant: () => void;
  onNavigateHistory: () => void;
  onSelectPlant: (plant: Plant) => void;
  onSelectHistoryItem: (item: ScanHistoryItem) => void;
}

const HomeView: React.FC<HomeViewProps> = ({ plants, history, onAddPlant, onSelectPlant, onSelectHistoryItem }) => {
  
  const healthyCount = plants.filter(p => p.healthStatus === 'Healthy').length;
  const criticalCount = plants.filter(p => p.healthStatus === 'Critical' || p.healthStatus === 'Needs Attention').length;

  return (
    <div className="pb-24 pt-4 px-4 max-w-2xl mx-auto space-y-8">
      {/* Header */}
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-display font-bold text-white tracking-wide">BARDAN</h1>
          <p className="text-neon-green text-sm font-sans tracking-widest uppercase">System Online</p>
        </div>
        <div className="w-10 h-10 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center">
             <span className="text-lg">🌿</span>
        </div>
      </header>

      {/* Analytics Grid */}
      <div className="grid grid-cols-3 gap-3">
          <div className="glass-panel p-3 rounded-xl flex flex-col items-center justify-center text-center border-t-2 border-neon-blue">
              <span className="text-2xl font-display font-bold text-white">{history.length}</span>
              <span className="text-[10px] text-slate-400 uppercase tracking-wide mt-1">Total Scans</span>
          </div>
          <div className="glass-panel p-3 rounded-xl flex flex-col items-center justify-center text-center border-t-2 border-neon-green">
              <span className="text-2xl font-display font-bold text-white">{plants.length}</span>
              <span className="text-[10px] text-slate-400 uppercase tracking-wide mt-1">My Plants</span>
          </div>
          <div className="glass-panel p-3 rounded-xl flex flex-col items-center justify-center text-center border-t-2 border-yellow-500">
              <span className="text-2xl font-display font-bold text-white">{criticalCount}</span>
              <span className="text-[10px] text-slate-400 uppercase tracking-wide mt-1">Alerts</span>
          </div>
      </div>

      {/* Recent Activity / History */}
      {history.length > 0 && (
          <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-sm font-bold text-slate-300 uppercase tracking-wider">Recent Scans</h2>
            </div>
            <div className="flex space-x-4 overflow-x-auto pb-4 scrollbar-hide">
                {history.slice().reverse().slice(0, 5).map((item) => (
                    <div 
                        key={item.id} 
                        onClick={() => onSelectHistoryItem(item)}
                        className="min-w-[140px] w-[140px] glass-panel p-2 rounded-xl flex flex-col space-y-2 shrink-0 border border-white/5 hover:border-white/20 transition cursor-pointer active:scale-95"
                    >
                         <div className="w-full h-24 rounded-lg overflow-hidden relative">
                             <img src={item.imageUrl} className="w-full h-full object-cover" />
                             <div className={`absolute top-1 right-1 w-2 h-2 rounded-full ${item.result.healthStatus === 'Healthy' ? 'bg-neon-green' : 'bg-red-500'}`} />
                         </div>
                         <div>
                             <h4 className="font-bold text-sm truncate">{item.result.name}</h4>
                             <p className="text-[10px] text-slate-400">{new Date(item.timestamp).toLocaleDateString()}</p>
                         </div>
                    </div>
                ))}
            </div>
          </div>
      )}

      {/* My Plants Collection */}
      <div>
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-sm font-bold text-slate-300 uppercase tracking-wider">My Collection</h2>
             <button 
                onClick={onAddPlant}
                className="text-neon-green text-xs font-bold uppercase hover:underline"
            >
                + Add New
            </button>
        </div>
        
        <div className="space-y-4">
            {plants.length === 0 ? (
            <div className="text-center py-12 glass-panel rounded-3xl border-dashed border-2 border-slate-700">
                <p className="text-slate-500 mb-4">Collection Empty</p>
                <button 
                    onClick={onAddPlant}
                    className="text-neon-green font-bold text-sm uppercase tracking-widest hover:underline"
                >
                    Initiate Scan
                </button>
            </div>
            ) : (
            plants.map((plant) => (
                <div 
                  key={plant.id} 
                  onClick={() => onSelectPlant(plant)}
                  className="glass-panel rounded-3xl overflow-hidden flex transition-transform active:scale-[0.98] duration-200 cursor-pointer hover:border-neon-green/50 group"
                >
                <div className="w-1/3 relative">
                    <img src={plant.imageUrl} alt={plant.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0f172a]/90"></div>
                </div>
                <div className="p-4 flex-1 flex flex-col justify-center">
                    <div className="flex justify-between items-start mb-1">
                    <h3 className="font-display font-bold text-lg leading-tight truncate pr-2 text-white">{plant.name}</h3>
                    <span className={`w-2 h-2 shrink-0 rounded-full mt-2 ${
                        plant.healthStatus === 'Healthy' ? 'bg-neon-green shadow-[0_0_8px_#00ff9d]' : 
                        plant.healthStatus === 'Critical' ? 'bg-red-500 shadow-[0_0_8px_red]' : 'bg-yellow-500'
                    }`}></span>
                    </div>
                    <p className="text-xs text-slate-400 italic mb-3 truncate">{plant.scientificName}</p>
                    <div className="flex flex-wrap gap-2 text-[10px] text-slate-300">
                        <span className="bg-slate-800/80 px-2 py-1 rounded border border-white/5 flex items-center">
                            💧 {plant.waterFrequency ? plant.waterFrequency.split(' ')[0] + '..' : 'Weekly'}
                        </span>
                        {/* Watering Reminder Badge */}
                        <span className="bg-blue-500/20 text-blue-300 px-2 py-1 rounded border border-blue-500/30 flex items-center font-bold">
                            ⏰ Water in 7d
                        </span>
                    </div>
                </div>
                </div>
            ))
            )}
        </div>
      </div>
    </div>
  );
};

export default HomeView;