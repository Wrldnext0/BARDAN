import React, { useState } from 'react';

interface AuthViewProps {
  onSuccess: () => void;
}

const AuthView: React.FC<AuthViewProps> = ({ onSuccess }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate Authentication
    if (email && password) {
        localStorage.setItem('bardan_user', JSON.stringify({ email }));
        onSuccess();
    } else {
        alert("Credentials required for bio-link.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative">
         <div className="w-full max-w-sm glass-panel p-8 rounded-3xl border border-neon-green/30 relative z-10">
             <div className="text-center mb-8">
                 <h1 className="text-4xl font-display font-bold text-white mb-2 tracking-wider">BARDAN</h1>
                 <p className="text-neon-green text-xs uppercase tracking-[0.2em]">AI Bio-Guardian Link</p>
             </div>

             <div className="flex bg-slate-900/50 p-1 rounded-lg mb-6">
                 <button 
                    onClick={() => setIsSignUp(false)}
                    className={`flex-1 py-2 text-sm font-bold rounded transition-colors ${!isSignUp ? 'bg-neon-green text-black' : 'text-slate-400 hover:text-white'}`}
                 >
                     SIGN IN
                 </button>
                 <button 
                    onClick={() => setIsSignUp(true)}
                    className={`flex-1 py-2 text-sm font-bold rounded transition-colors ${isSignUp ? 'bg-neon-green text-black' : 'text-slate-400 hover:text-white'}`}
                 >
                     SIGN UP
                 </button>
             </div>

             <form onSubmit={handleSubmit} className="space-y-4">
                 <div className="space-y-1">
                     <label className="text-[10px] uppercase text-neon-blue font-bold tracking-wider">Operator Email</label>
                     <input 
                        type="email" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-slate-900/80 border border-slate-700 rounded-lg p-3 text-white focus:border-neon-green focus:outline-none transition-colors"
                        placeholder="user@bardan.ai"
                     />
                 </div>
                 <div className="space-y-1">
                     <label className="text-[10px] uppercase text-neon-blue font-bold tracking-wider">Access Code</label>
                     <input 
                        type="password" 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full bg-slate-900/80 border border-slate-700 rounded-lg p-3 text-white focus:border-neon-green focus:outline-none transition-colors"
                        placeholder="••••••••"
                     />
                 </div>

                 <button 
                    type="submit"
                    className="w-full bg-neon-green text-black font-display font-bold py-4 rounded-xl uppercase tracking-widest hover:bg-white hover:shadow-[0_0_20px_rgba(0,255,157,0.4)] transition-all mt-4"
                 >
                     {isSignUp ? 'Initialize Profile' : 'Access System'}
                 </button>
             </form>
         </div>
         
         <div className="absolute bottom-6 text-slate-500 text-xs">
             v1.0.0 // SECURE CONNECTION
         </div>
    </div>
  );
};

export default AuthView;